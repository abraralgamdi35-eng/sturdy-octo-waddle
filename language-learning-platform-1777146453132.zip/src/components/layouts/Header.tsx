import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
// ... Header component implementation